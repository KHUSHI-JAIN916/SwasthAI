const caseSteps =
    document.querySelectorAll(".case-form-step");

const caseNextBtn =
    document.getElementById("caseNextBtn");

const casePrevBtn =
    document.getElementById("casePrevBtn");

const caseSubmitBtn =
    document.getElementById("caseSubmitBtn");

const currentCaseStep =
    document.getElementById("currentCaseStep");

const progressFill =
    document.querySelector(".case-progress-fill");

const caseForm =
    document.getElementById("caseForm");

const generateSummaryBtn =
    document.getElementById("generateSummaryBtn");

const aiCaseSummary =
    document.getElementById("aiCaseSummary");

const caseSuccessModal =
    document.getElementById("caseSuccessModal");


let currentStep = 0;


/* ===============================
   MOBILE SIDEBAR
================================ */

const menuToggle =
    document.getElementById("menuToggle");

const sidebar =
    document.querySelector(".sidebar");


menuToggle.addEventListener(
    "click",
    () => {

        sidebar.classList.toggle("show");

    }
);


/* ===============================
   SHOW STEP
================================ */

function showCaseStep() {

    caseSteps.forEach(
        (step, index) => {

            step.classList.toggle(
                "active-case-step",
                index === currentStep
            );

        }
    );


    currentCaseStep.textContent =
        currentStep + 1;


    const progress =
        ((currentStep + 1) /
        caseSteps.length) * 100;


    progressFill.style.width =
        `${progress}%`;


    casePrevBtn.style.visibility =
        currentStep === 0
            ? "hidden"
            : "visible";


    caseNextBtn.style.display =
        currentStep === caseSteps.length - 1
            ? "none"
            : "flex";


    caseSubmitBtn.style.display =
        currentStep === caseSteps.length - 1
            ? "flex"
            : "none";

}


/* ===============================
   VALIDATION
================================ */

function validateCaseStep() {

    const requiredInputs =
        caseSteps[currentStep]
            .querySelectorAll(
                "[required]"
            );


    for (
        const input
        of requiredInputs
    ) {

        if (!input.value.trim()) {

            input.focus();

            alert(
                "Please complete all required fields."
            );

            return false;

        }

    }


    return true;

}


/* ===============================
   NEXT
================================ */

caseNextBtn.addEventListener(
    "click",
    () => {

        if (!validateCaseStep()) {
            return;
        }


        currentStep++;

        showCaseStep();

    }
);


/* ===============================
   PREVIOUS
================================ */

casePrevBtn.addEventListener(
    "click",
    () => {

        if (currentStep > 0) {

            currentStep--;

            showCaseStep();

        }

    }
);


/* ===============================
   SYMPTOM CHIPS
================================ */

document
    .querySelectorAll(
        ".symptom-chips button"
    )
    .forEach(
        (button) => {

            button.addEventListener(
                "click",
                () => {

                    const complaint =
                        document.getElementById(
                            "chiefComplaint"
                        );


                    complaint.value =
                        button.textContent.trim();


                    document
                        .querySelectorAll(
                            ".symptom-chips button"
                        )
                        .forEach(
                            (chip) => {

                                chip.classList.remove(
                                    "selected-chip"
                                );

                            }
                        );


                    button.classList.add(
                        "selected-chip"
                    );

                }
            );

        }
    );


/* ===============================
   GENERATE AI SUMMARY
================================ */

generateSummaryBtn.addEventListener(
    "click",
    () => {

        const patient =
            document.getElementById(
                "casePatient"
            ).value ||
            "Selected Patient";


        const complaint =
            document.getElementById(
                "chiefComplaint"
            ).value ||
            "Not specified";


        const description =
            document.getElementById(
                "complaintDescription"
            ).value ||
            "Not provided";


        const severity =
            document.getElementById(
                "severity"
            ).value ||
            "Not specified";


        const symptomStart =
            document.getElementById(
                "symptomStart"
            ).value ||
            "Not specified";


        const prakriti =
            document.querySelector(
                'input[name="prakriti"]:checked'
            );


        const lifestyle = [

            document.getElementById("sleep").value,

            document.getElementById("activity").value,

            document.getElementById("stress").value,

            document.getElementById("diet").value

        ]
        .filter(Boolean)
        .join(", ");


        aiCaseSummary.innerHTML = `

            <div class="summary-section">

                <h4>Patient</h4>

                <p>
                    ${patient}
                </p>

            </div>


            <div class="summary-section">

                <h4>Chief Complaint</h4>

                <p>
                    ${complaint}
                </p>

            </div>


            <div class="summary-section">

                <h4>Complaint Description</h4>

                <p>
                    ${description}
                </p>

            </div>


            <div class="summary-section">

                <h4>Present Illness</h4>

                <p>
                    Symptoms started ${symptomStart}.
                    Reported severity is ${severity}.
                </p>

            </div>


            <div class="summary-section">

                <h4>Lifestyle Overview</h4>

                <p>
                    ${lifestyle || "Lifestyle details not provided."}
                </p>

            </div>


            <div class="summary-section">

                <h4>AYUSH Assessment</h4>

                <p>
                    Prakriti observation:
                    ${prakriti
                        ? prakriti.value
                        : "Not specified"
                    }.
                </p>

            </div>

        `;

    }
);


/* ===============================
   SAVE CASE
================================ */

caseForm.addEventListener(
    "submit",
    (event) => {

        event.preventDefault();

        caseSuccessModal.classList.add(
            "show-case-modal"
        );

    }
);


/* ===============================
   DASHBOARD
================================ */

document
    .getElementById(
        "goToDashboard"
    )
    .addEventListener(
        "click",
        () => {

            window.location.href =
                "dashboard.html";

        }
    );


/* ===============================
   INITIALIZE
================================ */

showCaseStep();