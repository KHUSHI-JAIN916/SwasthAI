/* =====================================
   VOICE CASE TAKING
===================================== */


const voiceRecordBtn =
    document.getElementById(
        "voiceRecordBtn"
    );


const voiceStatus =
    document.getElementById(
        "voiceStatus"
    );


const voiceHint =
    document.getElementById(
        "voiceHint"
    );


const voiceCircle =
    document.getElementById(
        "voiceCircle"
    );


const voiceTranscript =
    document.getElementById(
        "voiceTranscript"
    );


const languageSelect =
    document.getElementById(
        "languageSelect"
    );


const clearTranscriptBtn =
    document.getElementById(
        "clearTranscriptBtn"
    );


const copyTranscriptBtn =
    document.getElementById(
        "copyTranscriptBtn"
    );


const sendToCaseBtn =
    document.getElementById(
        "sendToCaseBtn"
    );


const menuToggle =
    document.getElementById(
        "menuToggle"
    );


const sidebar =
    document.querySelector(
        ".sidebar"
    );


/* ===============================
   MOBILE SIDEBAR
================================ */

menuToggle.addEventListener(
    "click",
    () => {

        sidebar.classList.toggle(
            "show"
        );

    }
);



/* ===============================
   SPEECH RECOGNITION SUPPORT
================================ */

const SpeechRecognition =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;


let recognition;

let isRecording = false;


if (SpeechRecognition) {

    recognition =
        new SpeechRecognition();


    recognition.continuous =
        true;


    recognition.interimResults =
        true;


    recognition.onresult =
        function(event) {

            let finalTranscript = "";

            let interimTranscript = "";


            for (
                let i =
                    event.resultIndex;

                i <
                    event.results.length;

                i++
            ) {

                const transcript =
                    event.results[i][0]
                        .transcript;


                if (
                    event.results[i]
                        .isFinal
                ) {

                    finalTranscript +=
                        transcript + " ";

                } else {

                    interimTranscript +=
                        transcript;

                }

            }


            voiceTranscript.value +=
                finalTranscript;


            if (
                interimTranscript
            ) {

                voiceStatus.textContent =
                    "Listening...";

            }

        };


    recognition.onend =
        function() {

            if (isRecording) {

                recognition.start();

            }

        };


    recognition.onerror =
        function(event) {

            voiceStatus.textContent =
                "Voice recognition error";

            voiceHint.textContent =
                event.error;

        };



    /* ===============================
       START / STOP
    ================================ */

    voiceRecordBtn.addEventListener(
        "click",
        () => {

            if (!isRecording) {


                recognition.lang =
                    languageSelect.value;


                recognition.start();


                isRecording =
                    true;


                voiceCircle.classList.add(
                    "recording"
                );


                voiceRecordBtn.classList.add(
                    "recording"
                );


                voiceRecordBtn.innerHTML = `

                    <i class="fa-solid fa-stop"></i>

                    Stop Recording

                `;


                voiceStatus.textContent =
                    "Listening...";


                voiceHint.textContent =
                    "Speak naturally. Your words will appear below.";


            } else {


                isRecording =
                    false;


                recognition.stop();


                voiceCircle.classList.remove(
                    "recording"
                );


                voiceRecordBtn.classList.remove(
                    "recording"
                );


                voiceRecordBtn.innerHTML = `

                    <i class="fa-solid fa-microphone"></i>

                    Start Recording

                `;


                voiceStatus.textContent =
                    "Recording stopped";


                voiceHint.textContent =
                    "You can edit the transcript manually.";

            }

        }
    );


} else {


    voiceRecordBtn.disabled =
        true;


    voiceStatus.textContent =
        "Speech recognition not supported";


    voiceHint.textContent =
        "Please use Google Chrome or another supported browser.";

}



/* ===============================
   CLEAR TRANSCRIPT
================================ */

clearTranscriptBtn.addEventListener(
    "click",
    () => {

        voiceTranscript.value =
            "";

    }
);



/* ===============================
   COPY TRANSCRIPT
================================ */

copyTranscriptBtn.addEventListener(
    "click",
    async () => {

        if (
            !voiceTranscript.value.trim()
        ) {

            alert(
                "No transcript available to copy."
            );

            return;

        }


        await navigator.clipboard.writeText(
            voiceTranscript.value
        );


        copyTranscriptBtn.innerHTML = `

            <i class="fa-solid fa-check"></i>

            Copied!

        `;


        setTimeout(
            () => {

                copyTranscriptBtn.innerHTML = `

                    <i class="fa-solid fa-copy"></i>

                    Copy Text

                `;

            },
            1500
        );

    }
);



/* ===============================
   USE IN NEW CASE
================================ */

sendToCaseBtn.addEventListener(
    "click",
    () => {

        const transcript =
            voiceTranscript.value.trim();


        if (!transcript) {

            alert(
                "Please record or enter case information first."
            );

            return;

        }


        /* Save temporarily */

        localStorage.setItem(
            "voiceCaseTranscript",
            transcript
        );


        /* Navigate */

        window.location.href =
            "case-taking.html";

    }
);