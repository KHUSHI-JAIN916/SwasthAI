/* =================================
   PROFILE MANAGEMENT
================================= */


/* GET CURRENT USER */

let currentUser =
    JSON.parse(
        localStorage.getItem(
            "ayushCurrentUser"
        )
    );


/* SECURITY */

if (!currentUser) {

    window.location.href =
        "index.html";

}


/* ELEMENTS */

const profileName =
    document.getElementById(
        "profileName"
    );


const profileRole =
    document.getElementById(
        "profileRole"
    );


const profileEmail =
    document.getElementById(
        "profileEmail"
    );


const detailName =
    document.getElementById(
        "detailName"
    );


const detailEmail =
    document.getElementById(
        "detailEmail"
    );


const detailRole =
    document.getElementById(
        "detailRole"
    );


const editProfileBtn =
    document.getElementById(
        "editProfileBtn"
    );


const editProfileCard =
    document.getElementById(
        "editProfileCard"
    );


const cancelProfileBtn =
    document.getElementById(
        "cancelProfileBtn"
    );


const profileForm =
    document.getElementById(
        "profileForm"
    );


const editName =
    document.getElementById(
        "editName"
    );


const editEmail =
    document.getElementById(
        "editEmail"
    );


const editRole =
    document.getElementById(
        "editRole"
    );


const logoutBtn =
    document.getElementById(
        "logoutBtn"
    );


/* DISPLAY USER */

function displayUser() {

    profileName.textContent =
        currentUser.name;


    profileRole.textContent =
        currentUser.role;


    profileEmail.textContent =
        currentUser.email;


    detailName.textContent =
        currentUser.name;


    detailEmail.textContent =
        currentUser.email;


    detailRole.textContent =
        currentUser.role;


    editName.value =
        currentUser.name;


    editEmail.value =
        currentUser.email;


    editRole.value =
        currentUser.role;

}


displayUser();


/* EDIT PROFILE */

editProfileBtn.addEventListener(
    "click",
    () => {

        editProfileCard.style.display =
            "block";


        editProfileCard.scrollIntoView({
            behavior: "smooth"
        });

    }
);


/* CANCEL */

cancelProfileBtn.addEventListener(
    "click",
    () => {

        editProfileCard.style.display =
            "none";

    }
);


/* SAVE PROFILE */

profileForm.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();


        const updatedName =
            editName.value.trim();


        const updatedEmail =
            editEmail.value
                .trim()
                .toLowerCase();


        const updatedRole =
            editRole.value;


        /* Update current user */

        currentUser.name =
            updatedName;


        currentUser.email =
            updatedEmail;


        currentUser.role =
            updatedRole;


        /* Save current user */

        localStorage.setItem(
            "ayushCurrentUser",
            JSON.stringify(
                currentUser
            )
        );


        /* Update users list */

        let users =
            JSON.parse(
                localStorage.getItem(
                    "ayushUsers"
                )
            ) || [];


        users =
            users.map(
                user => {

                    if (
                        user.email ===
                        currentUser.email
                    ) {

                        return currentUser;

                    }


                    return user;

                }
            );


        localStorage.setItem(
            "ayushUsers",
            JSON.stringify(users)
        );


        displayUser();


        editProfileCard.style.display =
            "none";


        alert(
            "Profile updated successfully!"
        );

    }
);


/* LOGOUT */

logoutBtn.addEventListener(
    "click",
    () => {

        const confirmLogout =
            confirm(
                "Are you sure you want to logout?"
            );


        if (
            confirmLogout
        ) {

            localStorage.removeItem(
                "ayushCurrentUser"
            );


            window.location.href =
                "index.html";

        }

    }
);


/* MOBILE MENU */

const menuToggle =
    document.getElementById(
        "menuToggle"
    );


const sidebar =
    document.querySelector(
        ".sidebar"
    );


menuToggle.addEventListener(
    "click",
    () => {

        sidebar.classList.toggle(
            "show"
        );

    }
);