const formSteps = document.querySelectorAll(".form-step");
const progressSteps = document.querySelectorAll(".progress-step");

const nextBtn = document.getElementById("nextBtn");
const prevBtn = document.getElementById("prevBtn");
const submitBtn = document.getElementById("submitBtn");

const patientForm = document.getElementById("patientForm");

const reviewData = document.getElementById("reviewData");

const successModal = document.getElementById("successModal");

const menuToggle = document.getElementById("menuToggle");
const sidebar = document.querySelector(".sidebar");


let currentStep = 0;


/* =========================
   MOBILE SIDEBAR
========================= */

menuToggle.addEventListener("click", () => {

    sidebar.classList.toggle("show");

});


/* =========================
   SHOW CURRENT STEP
========================= */

function showStep() {

    formSteps.forEach((step, index) => {

        step.classList.toggle(
            "active-form-step",
            index === currentStep
        );

    });


    progressSteps.forEach((step, index) => {

        step.classList.toggle(
            "active-step",
            index <= currentStep
        );

    });


    prevBtn.style.visibility =
        currentStep === 0
            ? "hidden"
            : "visible";


    nextBtn.style.display =
        currentStep === formSteps.length - 1
            ? "none"
            : "flex";


    submitBtn.style.display =
        currentStep === formSteps.length - 1
            ? "flex"
            : "none";

}


/* =========================
   VALIDATE CURRENT STEP
========================= */

function validateStep() {

    const inputs =
        formSteps[currentStep]
            .querySelectorAll(
                "input[required], select[required], textarea[required]"
            );


    for (let input of inputs) {

        if (!input.value.trim()) {

            input.focus();

            alert(
                "Please fill in all required fields."
            );

            return false;

        }

    }


    return true;

}


/* =========================
   NEXT
========================= */

nextBtn.addEventListener("click", () => {

    if (!validateStep()) {
        return;
    }


    if (
        currentStep === 2
    ) {

        generateReview();

    }


    currentStep++;

    showStep();

});


/* =========================
   PREVIOUS
========================= */

prevBtn.addEventListener("click", () => {

    if (currentStep > 0) {

        currentStep--;

        showStep();

    }

});


/* =========================
   REVIEW
========================= */

function generateReview() {

    const fields = [

        ["Full Name", "fullName"],

        ["Date of Birth", "dob"],

        ["Gender", "gender"],

        ["Blood Group", "bloodGroup"],

        ["Occupation", "occupation"],

        ["Phone Number", "phone"],

        ["Email Address", "email"],

        ["Address", "address"],

        ["Emergency Contact", "emergencyName"],

        ["Emergency Phone", "emergencyPhone"],

        ["Allergies", "allergies"],

        ["Existing Conditions", "conditions"]

    ];


    reviewData.innerHTML = "";


    fields.forEach((field) => {

        const label = field[0];

        const id = field[1];

        const value =
            document.getElementById(id).value ||
            "Not Provided";


        reviewData.innerHTML += `

            <div class="review-item">

                <span>${label}</span>

                <strong>${value}</strong>

            </div>

        `;

    });

}


/* =========================
   SUBMIT
========================= */

patientForm.addEventListener(
    "submit",
    (event) => {

        event.preventDefault();


        successModal.classList.add(
            "show-modal"
        );

    }
);


/* =========================
   GO TO PATIENT LIST
========================= */

document
    .getElementById("goToPatients")
    .addEventListener(
        "click",
        () => {

            window.location.href =
                "patients.html";

        }
    );


/* =========================
   INITIALIZE
========================= */

showStep();