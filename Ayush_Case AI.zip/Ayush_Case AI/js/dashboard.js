// ===============================
// SIDEBAR TOGGLE
// ===============================

const menuToggle = document.getElementById("menuToggle");

const sidebar = document.querySelector(".sidebar");


menuToggle.addEventListener("click", () => {

    sidebar.classList.toggle("show");

});


// ===============================
// NOTIFICATION BUTTON
// ===============================

const notificationBtn =
    document.querySelector(".notification-btn");


notificationBtn.addEventListener("click", () => {

    alert("You have 3 new notifications!");

});


// ===============================
// AI SUGGESTION BUTTONS
// ===============================

const suggestionButtons =
    document.querySelectorAll(".suggestion-btn");


suggestionButtons.forEach((button) => {

    button.addEventListener("click", () => {

        const action =
            button.innerText.trim();

        alert(action + " feature will open here!");

    });

});


// ===============================
// SIMPLE NUMBER ANIMATION
// ===============================

function animateNumber(element, target) {

    let current = 0;

    const increment =
        Math.ceil(target / 50);


    const timer =
        setInterval(() => {

            current += increment;


            if (current >= target) {

                current = target;

                clearInterval(timer);

            }


            element.textContent =
                current.toLocaleString();

        }, 30);

}


const patientCount =
    document.getElementById("patientCount");


window.addEventListener("load", () => {

    animateNumber(
        patientCount,
        1248
    );

});