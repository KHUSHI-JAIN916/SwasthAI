/* =====================================
   AI ASSISTANT DATA
===================================== */

const aiCaseData = {

    "Rahul Kumar": {

        summary:
            "The patient presents with recurring headaches and fatigue. The recorded information indicates that irregular sleep patterns and daily routine factors may be relevant for practitioner review.",

        ayush: [
            "Prakriti observation: Vata characteristics are recorded in the case.",
            "Routine-related factors should be reviewed by the practitioner.",
            "Further assessment should be based on complete patient history."
        ],

        confidence: "87%",

        flags: [
            "Recurring symptoms",
            "Irregular sleep pattern",
            "Fatigue reported"
        ],

        questions: [
            "When did the headaches first begin?",
            "How frequently do the symptoms occur?",
            "Are there any identifiable triggers?",
            "How many hours of sleep does the patient usually get?"
        ],

        followups: [
            "Complete practitioner review of symptom history.",
            "Record symptom frequency during follow-up.",
            "Review lifestyle and sleep routine.",
            "Schedule follow-up according to practitioner judgement."
        ]

    },


    "Priya Sharma": {

        summary:
            "The patient reports digestive discomfort and acidity after meals. The recorded case indicates that dietary patterns and symptom triggers may require further practitioner review.",

        ayush: [
            "Prakriti observation: Pitta characteristics are recorded.",
            "Dietary triggers should be documented clearly.",
            "Meal timing and lifestyle information may support further assessment."
        ],

        confidence: "89%",

        flags: [
            "Digestive discomfort",
            "Food-related trigger",
            "Acidity reported"
        ],

        questions: [
            "Which foods appear to worsen the discomfort?",
            "When do symptoms usually occur?",
            "Has the patient experienced changes in appetite?",
            "How regularly are meals consumed?"
        ],

        followups: [
            "Document dietary triggers.",
            "Review symptom changes over time.",
            "Complete lifestyle assessment.",
            "Schedule practitioner follow-up."
        ]

    },


    "Amit Singh": {

        summary:
            "The patient reports joint discomfort and stiffness that has developed gradually. The case information suggests that symptom duration, activity patterns and functional impact should be reviewed.",

        ayush: [
            "Prakriti observation: Kapha characteristics are recorded.",
            "Activity level may be relevant to practitioner assessment.",
            "Joint stiffness pattern should be documented during follow-up."
        ],

        confidence: "84%",

        flags: [
            "Long-duration symptoms",
            "Joint stiffness",
            "Low activity level"
        ],

        questions: [
            "Which joints are affected?",
            "Is stiffness worse at a particular time?",
            "Does physical activity change the symptoms?",
            "Has mobility been affected?"
        ],

        followups: [
            "Document affected joints.",
            "Track symptom intensity.",
            "Review physical activity routine.",
            "Arrange practitioner follow-up."
        ]

    },


    "Neha Verma": {

        summary:
            "The patient reports persistent fatigue and reduced energy. The recorded information indicates that sleep, stress and daily activity patterns should be explored further during practitioner review.",

        ayush: [
            "Prakriti observation: Vata characteristics are recorded.",
            "Stress and sleep factors may require additional documentation.",
            "Energy-level changes should be monitored over time."
        ],

        confidence: "85%",

        flags: [
            "Persistent fatigue",
            "High stress level",
            "Insufficient sleep"
        ],

        questions: [
            "When is fatigue most noticeable?",
            "How many hours does the patient sleep?",
            "Have there been recent lifestyle changes?",
            "Does rest improve the symptoms?"
        ],

        followups: [
            "Review sleep pattern.",
            "Document daily energy levels.",
            "Review stress-related factors.",
            "Schedule follow-up based on practitioner assessment."
        ]

    }

};



/* =====================================
   ELEMENTS
===================================== */

const generateAiBtn =
    document.getElementById(
        "generateAiBtn"
    );


const patientCaseSelect =
    document.getElementById(
        "patientCaseSelect"
    );


const aiProcessing =
    document.getElementById(
        "aiProcessing"
    );


const aiResults =
    document.getElementById(
        "aiResults"
    );


const aiSummaryText =
    document.getElementById(
        "aiSummaryText"
    );


const ayushObservation =
    document.getElementById(
        "ayushObservation"
    );


const confidenceScore =
    document.getElementById(
        "confidenceScore"
    );


const attentionFlags =
    document.getElementById(
        "attentionFlags"
    );


const suggestedQuestions =
    document.getElementById(
        "suggestedQuestions"
    );


const followUpList =
    document.getElementById(
        "followUpList"
    );



/* =====================================
   GENERATE ANALYSIS
===================================== */

generateAiBtn.addEventListener(
    "click",
    () => {

        aiResults.classList.remove(
            "show"
        );


        aiProcessing.classList.add(
            "show"
        );


        generateAiBtn.disabled =
            true;


        generateAiBtn.innerHTML = `

            <i class="fa-solid fa-spinner fa-spin"></i>

            Analyzing...

        `;


        setTimeout(
            () => {

                generateAiAnalysis();

            },
            1500
        );

    }
);



/* =====================================
   AI ANALYSIS FUNCTION
===================================== */

function generateAiAnalysis() {

    const selectedPatient =
        patientCaseSelect.value;


    const data =
        aiCaseData[
            selectedPatient
        ];


    /* SUMMARY */

    aiSummaryText.textContent =
        data.summary;


    /* AYUSH OBSERVATIONS */

    ayushObservation.innerHTML =
        "";


    data.ayush.forEach(
        (item) => {

            ayushObservation.innerHTML += `

                <div
                    class="ayush-observation-item"
                >

                    ${item}

                </div>

            `;

        }
    );


    /* CONFIDENCE */

    confidenceScore.textContent =
        data.confidence;


    /* FLAGS */

    attentionFlags.innerHTML =
        "";


    data.flags.forEach(
        (flag) => {

            attentionFlags.innerHTML += `

                <div
                    class="flag-item"
                >

                    <i
                        class="fa-solid fa-circle-exclamation"
                    ></i>

                    ${flag}

                </div>

            `;

        }
    );


    /* QUESTIONS */

    suggestedQuestions.innerHTML =
        "";


    data.questions.forEach(
        (question, index) => {

            suggestedQuestions.innerHTML += `

                <div
                    class="question-item"
                >

                    <div
                        class="question-number"
                    >

                        ${index + 1}

                    </div>


                    <div>

                        ${question}

                    </div>

                </div>

            `;

        }
    );


    /* FOLLOW UPS */

    followUpList.innerHTML =
        "";


    data.followups.forEach(
        (item) => {

            followUpList.innerHTML += `

                <div
                    class="followup-item"
                >

                    <i
                        class="fa-solid fa-circle-check"
                    ></i>

                    ${item}

                </div>

            `;

        }
    );


    /* SHOW RESULTS */

    aiProcessing.classList.remove(
        "show"
    );


    aiResults.classList.add(
        "show"
    );


    generateAiBtn.disabled =
        false;


    generateAiBtn.innerHTML = `

        <i
            class="fa-solid fa-robot"
        ></i>

        Generate New Analysis

    `;

}



/* =====================================
   MOBILE SIDEBAR
===================================== */

const menuToggle =
    document.getElementById(
        "menuToggle"
    );


const sidebar =
    document.querySelector(
        ".sidebar"
    );


menuToggle.addEventListener(
    "click",
    () => {

        sidebar.classList.toggle(
            "show"
        );

    }
);