const searchInput =
    document.getElementById("patientSearch");

const statusFilter =
    document.getElementById("statusFilter");

const rows =
    document.querySelectorAll("#patientTableBody tr");


function filterPatients() {

    const searchValue =
        searchInput.value.toLowerCase();

    const selectedStatus =
        statusFilter.value;


    rows.forEach((row) => {

        const patientText =
            row.innerText.toLowerCase();

        const patientStatus =
            row.dataset.status;


        const matchesSearch =
            patientText.includes(searchValue);


        const matchesStatus =
            selectedStatus === "all" ||
            patientStatus === selectedStatus;


        if (
            matchesSearch &&
            matchesStatus
        ) {

            row.style.display = "";

        } else {

            row.style.display = "none";

        }

    });

}


searchInput.addEventListener(
    "input",
    filterPatients
);


statusFilter.addEventListener(
    "change",
    filterPatients
);